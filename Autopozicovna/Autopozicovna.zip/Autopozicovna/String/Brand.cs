﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autopozicovna
{ 
    public class Brand
    {
        public string _Brand;

        public Brand(string _Brand)
        {
            this._Brand = _Brand;
        }
    }
}