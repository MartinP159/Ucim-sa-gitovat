﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autopozicovna
{
    public class Engine
    {
        public string fuel;

        public  Engine(string fuel)
        {
            this.fuel = fuel;
        }

    }
}
