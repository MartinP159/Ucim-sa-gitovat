﻿enum Type
{
    personalCar, motorcycle,truck, van
}
