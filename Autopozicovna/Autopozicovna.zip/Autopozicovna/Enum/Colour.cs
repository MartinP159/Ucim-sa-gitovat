﻿enum Colour
{
    white, black, green, blue, red
}
